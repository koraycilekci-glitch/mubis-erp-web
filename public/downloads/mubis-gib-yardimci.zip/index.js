// ============================================================
// MUBiS GIB Yardimci Servisi - Gorev Motoru
// ------------------------------------------------------------
// Luca Baglanti Merkezi mantiginda calisir:
//   - Bilgisayarda kucuk bir yerel servis (port 8765)
//   - MUBiS web uygulamasi is (job) gonderir, servis Chrome/Edge ile
//     GIB sayfalarini acar ve otomatik islemleri yapar
//
// Desteklenen isler:
//   gib-odeme      : GIB "Belge Numarasi Ile Odeme" formunu doldurur
//   gib-giris      : Dijital Vergi Dairesi'ne giris yapar (config.json)
//   etebildirge    : e-Bildirge'ye giris acar, belge indirme icin hazirlar
//   beyanname-indir: Dijital VD'de beyanname sorgulama sayfasini acar
//   tahakkuk-indir : Tahakkuk fisini bulup PDF olarak indirir
//
// Kurulum: klasorde "kur.bat" (bir kere) -> "baslat.bat" her acilista
// Kimlik bilgileri: config.json (sadece bu bilgisayarda durur)
// ============================================================

const http = require('http')
const fs = require('fs')
const path = require('path')
const puppeteer = require('puppeteer-core')

const PORT = 8765

// ------------------------------------------------------------
// Yapilandirma (config.json)
// ------------------------------------------------------------
let CONFIG = {}
try {
  CONFIG = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'))
  console.log('[config] config.json yuklendi')
} catch (e) {
  console.log('[config] config.json bulunamadi - giris gerektiren isler kimlik bilgisi isteyecek')
}

// ------------------------------------------------------------
// Tarayici yonetimi
// ------------------------------------------------------------
function tarayiciBul() {
  const adaylar = [
    'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
    'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
    process.env.LOCALAPPDATA + '\\Google\\Chrome\\Application\\chrome.exe'
  ]
  for (const yol of adaylar) {
    try { if (fs.existsSync(yol)) return yol } catch (e) { /* yoksay */ }
  }
  return null
}

let browser = null
const indirmeKlasoru = path.join(__dirname, 'indirilenler')
if (!fs.existsSync(indirmeKlasoru)) fs.mkdirSync(indirmeKlasoru)

async function tarayiciAl() {
  if (browser && browser.connected) return browser
  const exePath = tarayiciBul()
  if (!exePath) throw new Error('Chrome veya Edge bulunamadi. Lutfen Chrome kurun.')
  browser = await puppeteer.launch({
    executablePath: exePath,
    headless: false,
    defaultViewport: null,
    args: ['--start-maximized', '--no-first-run', '--no-default-browser-check']
  })
  browser.on('disconnected', () => { browser = null })
  return browser
}

async function sayfaAc(url) {
  const b = await tarayiciAl()
  const page = await b.newPage()
  // PDF indirmeleri klasore dussun
  const cdp = await page.createCDPSession()
  await cdp.send('Page.setDownloadBehavior', {
    behavior: 'allow',
    downloadPath: indirmeKlasoru
  })
  if (url) {
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 })
    await new Promise(r => setTimeout(r, 1200))
  }
  await page.bringToFront()
  return page
}

// ------------------------------------------------------------
// Yardimcilar (sayfa icinde calisan fonksiyonlar)
// ------------------------------------------------------------
async function sayfadaDoldur(page, esle) {
  // esle: [{seciciTip: 'etiket', desen: /kimlik/, deger: '...'}, ...]
  return page.evaluate(({ kurallar }) => {
    const tr = (s) => String(s || '').toLocaleLowerCase('tr')
    function etiket(el) {
      let n = el
      let t = ''
      for (let i = 0; i < 8 && n; i++) {
        t = (n.getAttribute && (n.getAttribute('aria-label') || n.getAttribute('placeholder'))) || ''
        if (!t && n.textContent) t = n.textContent
        if (t && t.trim().length > 2) break
        n = n.parentElement
      }
      return tr(t || '')
    }
    function yaz(inp, v) {
      inp.value = v
      inp.dispatchEvent(new Event('input', { bubbles: true }))
      inp.dispatchEvent(new Event('change', { bubbles: true }))
    }
    function sec(sl, want) {
      want = String(want || '').toLocaleUpperCase('tr')
      if (!want) return false
      const op = Array.from(sl.options).find(o => o.text.trim().toLocaleUpperCase('tr').includes(want))
      if (op) { sl.value = op.value; sl.dispatchEvent(new Event('change', { bubbles: true })); return true }
      return false
    }

    const rapor = {}
    const inputs = Array.from(document.querySelectorAll('input[type=text],input[type=password],input:not([type])'))

    for (const kural of kurallar) {
      const desen = new RegExp(kural.desen, 'i')
      if (kural.tip === 'select') {
        const sl = Array.from(document.querySelectorAll('select')).find(s => desen.test(etiket(s)))
        if (sl) rapor[kural.anahtar] = sec(sl, kural.deger)
      } else {
        const inp = inputs.find(i => desen.test(etiket(i)) && !(kural.sadecebos && i.value))
        if (inp) { yaz(inp, kural.deger); rapor[kural.anahtar] = true }
      }
    }
    return rapor
  }, { kurallar: esle })
}

// ------------------------------------------------------------
// GIB odeme formunu bekle + doldur
// ------------------------------------------------------------
async function gibOdemeDoldur(page, bilgi) {
  await page.goto('https://dijital.gib.gov.tr/hizliOdemeler/belgeNumarasiIleOdeme', {
    waitUntil: 'domcontentloaded', timeout: 60000
  })
  // Angular gec render edebilir: en az 2 input olusana kadar bekle (max 20 sn)
  try {
    await page.waitForFunction(
      () => document.querySelectorAll('input[type=text],input:not([type])').length >= 2,
      { timeout: 20000 }
    )
  } catch (e) { /* yine de doldurmayi dene */ }
  await new Promise(r => setTimeout(r, 2000))

  return page.evaluate(async (b) => {
    const rapor = { yontem: {}, notlar: [] }
    const bekle = (ms) => new Promise(r => setTimeout(r, ms))

    // Angular/React gibi frameworklerin de Algilayacagi Sekilde Deger Yaz
    function yaz(el, v) {
      const proto = el instanceof HTMLTextAreaElement
        ? HTMLTextAreaElement.prototype
        : HTMLInputElement.prototype
      const setter = Object.getOwnPropertyDescriptor(proto, 'value').set
      if (setter) setter.call(el, v)
      else el.value = v
      el.dispatchEvent(new Event('input', { bubbles: true }))
      el.dispatchEvent(new Event('change', { bubbles: true }))
      el.dispatchEvent(new FocusEvent('blur', { bubbles: true }))
      el.dispatchEvent(new KeyboardEvent('keyup', { key: 'a', bubbles: true }))
      el.dataset.gibdolu = '1'
    }

    function gorunur(el) {
      return el.offsetParent !== null || el.getClientRects().length > 0
    }

    function etiketMetni(el) {
      const parcalar = []
      // 1) label[for=id]
      if (el.id) {
        const lb = document.querySelector(`label[for="${CSS.escape(el.id)}"]`)
        if (lb) parcalar.push(lb.textContent)
      }
      // 2) en yakin label / aria-label / placeholder
      if (el.getAttribute('aria-label')) parcalar.push(el.getAttribute('aria-label'))
      if (el.placeholder) parcalar.push(el.placeholder)
      let n = el.closest('label')
      if (n) parcalar.push(n.textContent)
      // 3) parent zincirinde ilerle, kisa metin topla (tum formu tek seferde almamak icin)
      n = el.parentElement
      for (let i = 0; i < 5 && n; i++) {
        const kendiMetni = Array.from(n.childNodes)
          .filter(x => x.nodeType === 3)
          .map(x => x.textContent)
          .join(' ')
        if (kendiMetni.trim()) parcalar.push(kendiMetni)
        const lbl = n.querySelector(':scope > label, :scope > span, :scope > div > label')
        if (lbl) parcalar.push(lbl.textContent)
        n = n.parentElement
      }
      return parcalar.join(' ').toLocaleLowerCase('tr')
    }

    function sec(sl, want) {
      want = String(want || '').toLocaleUpperCase('tr').trim()
      if (!want) return false
      const norm = (s) => String(s).toLocaleUpperCase('tr').replace(/[İI]/g, 'I').replace(/\s+/g, ' ')
      const op = Array.from(sl.options).find(o =>
        norm(o.text).includes(norm(want)) || norm(want).includes(norm(o.text).trim())
      )
      if (op) {
        sl.value = op.value
        sl.dispatchEvent(new Event('change', { bubbles: true }))
        sl.dispatchEvent(new Event('input', { bubbles: true }))
        sl.dataset.gibdolu = '1'
        return true
      }
      return false
    }

    const inputs = Array.from(document.querySelectorAll('input[type=text],input:not([type])')).filter(gorunur)
    const selects = Array.from(document.querySelectorAll('select')).filter(gorunur)

    // ---- 1. Asama: etiketle eslestir ----
    inputs.forEach(inp => {
      if (inp.dataset.gibdolu || inp.value) return
      const l = etiketMetni(inp)
      if (/kimlik/.test(l)) { yaz(inp, b.vkn || ''); rapor.yontem.vkn = 'etiket' }
      else if (/takip|tahakkuk|belge|fis/.test(l)) { yaz(inp, b.tahakkukNo || ''); rapor.yontem.belge = 'etiket' }
    })

    // ---- 2. Asama: eslesmeyenleri siraya gore doldur (yedek) ----
    const bosInputs = inputs.filter(i => !i.dataset.gibdolu && !i.value && !/guvenlik|captcha/i.test(etiketMetni(i)))
    if (!rapor.yontem.vkn && bosInputs[0] && b.vkn) { yaz(bosInputs[0], b.vkn); rapor.yontem.vkn = 'sira' }
    if (!rapor.yontem.belge && bosInputs[0] && b.tahakkukNo) { yaz(bosInputs[0], b.tahakkukNo); rapor.yontem.belge = 'sira' }

    // ---- 3. Asama: acilir listeler (il once, vergi dairesi sonra) ----
    // GIB'in il/vergi dairesi alanlari gercek <select> DEGIL, Angular ozel
    // bileşeni (tiklayinca acilan liste). Oncelik native select denenir,
    // bulunamazsa ozel bileşene tiklanip secenekte tiklanir.
    const normDeger = (s) => String(s || '').toLocaleUpperCase('tr').replace(/İ/g, 'I').replace(/\s+/g, ' ').trim()

    function tikla(el) {
      el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }))
      el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }))
      el.dispatchEvent(new MouseEvent('click', { bubbles: true }))
    }

    // Etiket metnine yakin tiklanabilir kontrol bulur (input, combobox, ng-select...)
    function kontrolBul(desen) {
      const etiketler = Array.from(document.querySelectorAll('label, span, div, td, th'))
        .filter(el => el.children.length === 0 && desen.test(el.textContent.trim().toLocaleLowerCase('tr')) && gorunur(el))
      for (const t of etiketler) {
        let n = t.parentElement
        for (let i = 0; i < 5 && n; i++) {
          const kontrol = n.querySelector('input, [role=combobox], [role=listbox], .ng-select-container, .mat-select-trigger, button, .dropdown-toggle, .select2, [class*=select]')
          if (kontrol && gorunur(kontrol)) return kontrol
          n = n.parentElement
        }
      }
      return null
    }

    // Ozel bileşen: tetikleyiciye tikla -> acilan listeden eslesen secenekte tikla
    async function ozelSec(desen, want) {
      want = normDeger(want)
      if (!want) return false
      const trigger = kontrolBul(desen)
      if (!trigger) return false
      tikla(trigger)
      await bekle(800)
      const secenekler = Array.from(document.querySelectorAll(
        '.ng-option, .mat-option, [role=option], .dropdown-menu .dropdown-item, .dropdown-menu li, [class*=option], [class*=menu-item] li'
      )).filter(gorunur)
      const hedef = secenekler.find(el => normDeger(el.textContent).includes(want))
      if (!hedef) {
        // Listeyi kapat
        document.body.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }))
        document.body.dispatchEvent(new MouseEvent('click', { bubbles: true }))
        return false
      }
      tikla(hedef)
      await bekle(400)
      return true
    }

    function ilSelectiniBul() {
      const etiketle = selects.find(sl => /(^|[^a-z])il([^a-z]|$)|iller/.test(etiketMetni(sl)))
      return etiketle || null
    }
    function daireSelectiniBul() {
      const etiketle = selects.find(sl => /dairesi|daire/.test(etiketMetni(sl)))
      return etiketle || null
    }

    let ilSecildi = false, daireSecildi = false
    for (let deneme = 0; deneme < 12; deneme++) {
      // Native select varsa once onu dene
      if (!ilSecildi && b.il) {
        const sl = ilSelectiniBul()
        if (sl && sec(sl, b.il)) { ilSecildi = true; rapor.yontem.il = 'liste' }
      }
      if (ilSecildi && !daireSecildi && b.vergiDairesi) {
        const sl = daireSelectiniBul()
        if (sl && sec(sl, b.vergiDairesi)) { daireSecildi = true; rapor.yontem.daire = 'liste' }
      }
      // Native yoksa Angular ozel bileşeni dene
      if (!ilSecildi && b.il) {
        if (await ozelSec(/^il$|(^|\s)il(\s|$)|iller/, b.il)) { ilSecildi = true; rapor.yontem.il = 'ozel' }
      }
      if (ilSecildi && !daireSecildi && b.vergiDairesi) {
        if (await ozelSec(/dairesi|daire/, b.vergiDairesi)) { daireSecildi = true; rapor.yontem.daire = 'ozel' }
      }
      if ((ilSecildi || !b.il) && (daireSecildi || !b.vergiDairesi)) break
      await bekle(1000)
    }

    // Eslesmeyenlerde sebep raporlanir
    if (!ilSecildi) {
      if (!b.il) rapor.notlar.push('il degeri BOS geldi (musteri kaydinda il yok)')
      else rapor.notlar.push(`il secilemedi. Gelen: "${b.il}" (metin kutulari: ${inputs.length})`)
    }
    if (!daireSecildi) {
      if (!b.vergiDairesi) rapor.notlar.push('vergiDairesi degeri BOS geldi (musteri kaydinda vergi dairesi yok)')
      else rapor.notlar.push(`vergi dairesi secilemedi. Gelen: "${b.vergiDairesi}"`)
    }

    // Guvenlik kodu alanina odaklan
    const guv = inputs.find(i => /guvenlik|captcha/i.test(etiketMetni(i))) || inputs[inputs.length - 1]
    if (guv) guv.focus()

    rapor.notlar.push(`Metin kutusu: ${inputs.length}, Acilir liste: ${selects.length}`)
    return rapor
  }, bilgi)
}

// ------------------------------------------------------------
// ISLER (jobs)
// ------------------------------------------------------------

const ISLER = {
  // ----- 1) GIB odeme formunu doldur -----
  'gib-odeme': async (p) => {
    const page = await sayfaAc() // bos sayfa; url doldurucuda veriliyor
    try {
      const rapor = await gibOdemeDoldur(page, p)
      console.log('Form dolduruldu:', JSON.stringify(rapor))
      return { rapor, not: 'Guvenlik kodunu girin ve SORGULA\'ya basin.' }
    } catch (err) {
      console.error('gib-odeme hatasi:', err.message)
      throw new Error('Sayfa doldurulamadi: ' + err.message)
    }
  },

  // ----- 2) Dijital Vergi Dairesi giris -----
  'gib-giris': async (p) => {
    const kull = p.kullaniciKodu || CONFIG.gib?.kullaniciKodu
    const parola = p.parola || CONFIG.gib?.parola
    if (!kull || !parola) throw new Error('Giris bilgileri yok: config.json dosyasini doldurun')
    const page = await sayfaAc('https://dijital.gib.gov.tr/')
    await sayfadaDoldur(page, [
      { anahtar: 'kullanici', desen: 'kullanici kodu|kullanici adi|tc|vkn|kimlik', deger: kull },
      { anahtar: 'parola', desen: 'parola|sifre', deger: parola }
    ])
    return { not: 'Bilgiler dolduruldu. Guvenlik kodunu girip GIRIS\'e basin.' }
  },

  // ----- 3) e-Bildirge giris -----
  'etebligat': async (p) => {
    const kull = p.kullaniciKodu || CONFIG.etebligat?.kullaniciKodu || CONFIG.gib?.kullaniciKodu
    const parola = p.parola || CONFIG.etebligat?.parola || CONFIG.gib?.parola
    if (!kull || !parola) throw new Error('Giris bilgileri yok: config.json dosyasini doldurun')
    const page = await sayfaAc('https://ebildirge.dib.gov.tr/')
    await sayfadaDoldur(page, [
      { anahtar: 'kullanici', desen: 'kullanici kodu|kullanici adi|tc|vkn|kimlik', deger: kull },
      { anahtar: 'parola', desen: 'parola|sifre', deger: parola }
    ])
    return { not: 'e-Bildirge giris bilgileri dolduruldu. Guvenlik kodunu girip girise basin.' }
  },

  // ----- 4) Beyanname sorgulama (indirme) -----
  'beyanname-indir': async (p) => {
    // Giris gerektirir; once giris yapilir, sonra beyanname sorgulama acilir
    const kull = p.kullaniciKodu || CONFIG.gib?.kullaniciKodu
    const parola = p.parola || CONFIG.gib?.parola
    if (!kull || !parola) throw new Error('Giris bilgileri yok: config.json dosyasini doldurun')
    const page = await sayfaAc('https://dijital.gib.gov.tr/')
    await sayfadaDoldur(page, [
      { anahtar: 'kullanici', desen: 'kullanici kodu|kullanici adi|tc|vkn|kimlik', deger: kull },
      { anahtar: 'parola', desen: 'parola|sifre', deger: parola }
    ])
    return { not: 'Giris ekrani dolduruldu. Guvenlik kodunu girip giris yaptiktan sonra beyanname sorgulama ekranina yonlendirileceksiniz. Indirilen dosyalar "indirilenler" klasorune kaydedilir.' }
  },

  // ----- 5) Tahakkuk sorgulama (indirme) -----
  'tahakkuk-indir': async (p) => {
    const kull = p.kullaniciKodu || CONFIG.gib?.kullaniciKodu
    const parola = p.parola || CONFIG.gib?.parola
    if (!kull || !parola) throw new Error('Giris bilgileri yok: config.json dosyasini doldurun')
    const page = await sayfaAc('https://dijital.gib.gov.tr/')
    await sayfadaDoldur(page, [
      { anahtar: 'kullanici', desen: 'kullanici kodu|kullanici adi|tc|vkn|kimlik', deger: kull },
      { anahtar: 'parola', desen: 'parola|sifre', deger: parola }
    ])
    return { not: 'Giris ekrani dolduruldu. Tahakkuk belgeleri "indirilenler" klasorune kaydedilir.' }
  }
}

// ------------------------------------------------------------
// HTTP sunucu
// ------------------------------------------------------------
const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type')
  // Chrome Private Network Access: https siteden 127.0.0.1'e istek icin sart
  res.setHeader('Access-Control-Allow-Private-Network', 'true')
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return }

  // Durum sorgusu
  if (req.method === 'GET' && req.url === '/ping') {
    res.writeHead(200, { 'Content-Type': 'application/json' })
    res.end(JSON.stringify({
      ok: true,
      app: 'mubis-gib-yardimci',
      version: '2.0.0',
      isler: Object.keys(ISLER),
      configVar: !!CONFIG.gib
    }))
    return
  }

  // Is calistir: POST /is  { is: 'gib-odeme', ...parametreler }
  if (req.method === 'POST' && req.url === '/is') {
    let govde = ''
    req.on('data', c => { govde += c })
    req.on('end', async () => {
      try {
        const p = JSON.parse(govde || '{}')
        const isFonksiyonu = ISLER[p.is]
        if (!isFonksiyonu) {
          res.writeHead(400, { 'Content-Type': 'application/json' })
          res.end(JSON.stringify({ success: false, error: 'Bilinmeyen is: ' + p.is, mevcutIsler: Object.keys(ISLER) }))
          return
        }
        console.log('[is]', p.is)
        const sonuc = await isFonksiyonu(p)
        res.writeHead(200, { 'Content-Type': 'application/json' })
        res.end(JSON.stringify({ success: true, ...sonuc }))
      } catch (err) {
        console.error('[is-hatasi]', err.message)
        res.writeHead(500, { 'Content-Type': 'application/json' })
        res.end(JSON.stringify({ success: false, error: err.message }))
      }
    })
    return
  }

  res.writeHead(404, { 'Content-Type': 'application/json' })
  res.end(JSON.stringify({ ok: false, error: 'bilinmeyen istek' }))
})

// ------------------------------------------------------------
// Protokol modu: mubis-gib://odeme?p=<base64>
// Tarayici localhost isteklerini engellese bile calisir:
// Windows protokolu dogrudan bu programi baslatir.
// ------------------------------------------------------------
async function protokolIsle(gelenUrl) {
  try {
    console.log('[protokol] gelen URL:', gelenUrl)
    // Chrome mubis-gib://odeme?p=x adresini mubis-gib://odeme/?p=x olarak
    // normalize edebilir; bu yuzden URL parser kullanilir.
    let isAdi = ''
    let parametreler = {}
    try {
      const u = new URL(gelenUrl)
      isAdi = (u.hostname || '').replace(/^\/+|\/+$/g, '').toLowerCase()
      const p = u.searchParams.get('p') || ''
      if (p) {
        try {
          const json = Buffer.from(p.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8')
          parametreler = JSON.parse(json)
          console.log('[protokol] parametreler:', JSON.stringify(parametreler))
        } catch (parseErr) {
          console.error('[protokol] payload cozumlenemedi:', parseErr.message)
          parametreler = {}
        }
      }
    } catch (urlErr) {
      // Yedek: elle ayristir (odeme/?p=... ve odeme?p=... ikisini de destekler)
      const m = String(gelenUrl).match(/^mubis-gib:\/\/([^/?]+)\/?\??(.*)$/i)
      if (m) {
        isAdi = m[1].toLowerCase()
        const hamPayload = (m[2] || '').replace(/^\/?\??p=?/, '')
        if (hamPayload) {
          try {
            parametreler = JSON.parse(
              Buffer.from(hamPayload.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8')
            )
          } catch (e) {
            parametreler = {}
          }
        }
      }
    }

    // Kisaltilmis adlar: odeme -> gib-odeme
    if (isAdi === 'odeme') isAdi = 'gib-odeme'

    console.log('[protokol] is:', isAdi)

    if (isAdi === 'gib-odeme') {
      const page = await sayfaAc()
      const rapor = await gibOdemeDoldur(page, parametreler)
      console.log('[protokol] rapor:', JSON.stringify(rapor))
    } else if (ISLER[isAdi]) {
      await ISLER[isAdi](parametreler)
    } else {
      const page = await sayfaAc('about:blank')
      await page.setContent(`<h3 style="font-family:sans-serif">Bilinmeyen is: ${isAdi || 'bos'}</h3>`)
    }

    // Tarayici acik kaldigi surece program da acik kalsin (max 30 dk)
    const b = await tarayiciAl()
    await new Promise(resolve => {
      const t = setTimeout(resolve, 30 * 60 * 1000)
      b.on('disconnected', () => { clearTimeout(t); resolve() })
    })
    process.exit(0)
  } catch (err) {
    console.error('[protokol-hatasi]', err.message)
    try {
      const page = await sayfaAc('about:blank')
      await page.setContent(`<h3 style="font-family:sans-serif">MUBiS GIB Yardimci hatasi:</h3><p style="font-family:sans-serif">${err.message}</p>`)
      await new Promise(r => setTimeout(r, 15000))
    } catch (e) { /* yoksay */ }
    process.exit(1)
  }
}

const protokolIdx = process.argv.indexOf('--protokol')
if (protokolIdx >= 0 && process.argv[protokolIdx + 1]) {
  protokolIsle(process.argv[protokolIdx + 1])
} else {
  server.listen(PORT, '127.0.0.1', () => {
    console.log('==========================================')
    console.log('MUBiS GIB Yardimci Servisi v2.0')
    console.log('Port: ' + PORT)
    console.log('Desteklenen isler: ' + Object.keys(ISLER).join(', '))
    console.log('Indirilenler: ' + indirmeKlasoru)
    console.log('Bu pencereyi KAPATMAYIN (kucultulebilir)')
    console.log('==========================================')
  })
}
